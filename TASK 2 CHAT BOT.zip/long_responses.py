import random

R_EATING = "I don't like eating anything because I'm a bot obviously!"
R_ADVICE = "If I were you, I would go to the internet and type exactly what you wrote there!"
R_TENNIS = "Tennis is a popular racquet sport played between two individuals (singles) or two teams of two players each (doubles). The primary objective is to hit a ball over a net and into the opponent's court in such a way that the opponent cannot return it. The game is played on a rectangular court with a net in the middle."
R_CRICKET = "Cricket is a popular bat-and-ball sport played between two teams, each consisting of 11 players. The game is widely followed and played in many countries, especially in England, Australia, India, Pakistan, South Africa, the West Indies, and other nations. Cricket has several formats, with the most common being Test matches, One Day Internationals (ODIs), and Twenty20 (T20) matches."
R_ORIGIN = "First I was an idea,then a Bunch of Googlers in California started doin a lot of experiments,nd that's Where I came from..."
R_FRIEND = "Iam your Virtual Friend.."
R_WEATHER = "30°F partly cloudy"
R_BOOKS = "'The Hobbit' by J.R.R. Tolkien 'Harry Potter' series by J.K. Rowling 'A Game of Thrones' by George R.R. Martin 'The Name of the Wind' by Patrick Rothfuss 'The Lies of Locke Lamora' by Scott Lynch"